var data = {
  description: "Test for stuff",
  versions: ["v1.0.3"],
  config: {
    doClearGameArea: true,
    doFriction: true,
    doPenRes: false,
    doCollision: false,
    doCombinition: false,
    doGravity: false,
    doAbsoluteGravity: true,
    doWorldBorder: false,

    doDrawPath: false,
    doVelVec: false,

    gameSpeed: 1,
    gameIntTime: 20,
    gameScale: 1,
    gameSize: [500, 500], // 0 if none
    // gameSize: [0, 0], // 0 if none

    accPlayer: 1, // Player Acceleration
  },
  phys: {
    fric: 0.01,
    G: 4,
    g: [0, 0.5]
  },
  entities: [
    {
      x: -50,
      y: 50,
      r: 30,
      color: "hsl(0, 100%, 50%)",
      m: 40,
      elast: 1,
      vel: [15, 0],
      sound: "c4"
    },
    // {
    //   x: -50,
    //   y: 50,
    //   r: 20,
    //   color: "hsl(45, 100%, 50%)",
    //   m: 40,
    //   elast: 1,
    //   vel: [14, 0],
    //   sound: "c5"
    // },

    // {
    //   x: 500,
    //   y: 400,
    //   r: 15,
    //   color: "hsl(60, 100%, 50%)",
    //   m: 40,
    //   elast: 1,
    //   vel: [1, -0.4]
    // },
  ],
  walls: [
    {
      start: [0, 250],
      end: [200, 450],
      color: "white",
      thickness: 5,
      elast: 1
    },
    {
      start: [500, 250],
      end: [300, 450],
      color: "white",
      thickness: 5,
      elast: 1
    }
  ],
  onTick: function () {

    if ((counter + 1) % 100 == 0) {
      switch (bls.length) {
        case 1:
          bls.push(new ball(-50, 50, 30, "hsl(45, 100%, 50%)", 30, 1, [15, 0], "d4"));
          break;
        case 2:
          bls.push(new ball(-50, 50, 30, "hsl(90, 100%, 50%)", 30, 1, [15, 0], "e4"));
          break;
        case 3:
          bls.push(new ball(-50, 50, 30, "hsl(135, 100%, 50%)", 30, 1, [15, 0], "f4"));
          break;
        case 4:
          bls.push(new ball(-50, 50, 30, "hsl(180, 100%, 50%)", 30, 1, [15, 0], "g4"));
          break;
        case 5:
          bls.push(new ball(-50, 50, 30, "hsl(225, 100%, 50%)", 30, 1, [15, 0], "a4"));
          break;
        case 6:
          bls.push(new ball(-50, 50, 30, "hsl(315, 100%, 50%)", 30, 1, [15, 0], "b4"));
          break;
        case 7:
          bls.push(new ball(-50, 50, 30, "hsl(360, 100%, 50%)", 30, 1, [15, 0], "c5"));
          break;





        default:

      }
    }


    for (var i = 0; i < bls.length; i++) {
      // bls[i].color = "hsl(" + counter + ", 100%, 50%)";
      // bls[i].r = Math.sqrt((bls[i].r + ran(0, 10)/50)**2);
      //
      // if (bls[i].r > ran(25, 300)) {
      //   bls[i].r = bls[i].r / 2
      //   var newCol = Number(bls[i].color.replace("hsl(", "").replace(", 100%, 50%)", "")) + ran(-5, 40)
      //
      //   bls.push(new ball(bls[i].pos.x + ran(-5, 5), bls[i].pos.y + ran(-5, 5), bls[i].r, "hsl(" + newCol + ", 100%, 50%)", 10, 1, [0, 0]))
      //   if (ran(0, 6) == 0) {
      //     bls[i].exist = false;
      //   }
      //
      //   // sound.diamondPiep.cloneNode(true).play();
      //
      // }
    }
    // bls[0].color = "hsl(" + counter + ", 100%, 50%)";
    // friction += 0.00001

  },
  onCollision: function (b1, b2) {
    // b1.r = Math.sqrt((b1.r + 2)**2);
    // b1.vel = b1.vel.mul(1.2);
    // b1.m += 0.2;
    // b2.r = Math.sqrt((b2.r + 2)**2);
    // b2.vel = b2.vel.mul(1.2);
    // b2.m += 0.2;
    // sound.waterdrop.cloneNode(true).play();



    // record.audioContext.createMediaElementSource(sound.waterdrop.cloneNode(true));

  },
  onWorldBorder: function (b1) {
    // sound.slimePop.cloneNode(true).play();


    sound.woodenPop.cloneNode(true).play();

    // b1.vel = b1.vel.mul(1.1);
    // bls.push(new ball(250, 250, b1.r, "hsl(" + ran(0, 359) + ", 100%, 50%)", b1.m, 1, [ran(-100, 100) / 100 * bls[0].vel.mag(), ran(-100, 100) / 100 * bls[0].vel.mag()]))






  },
  onWallCollision: function (b, w) {
    // console.log("col");
    // sound.woodenPop.cloneNode(true).play();
    // bls[0].vel.mul(1.1);

    sound[b.sound].cloneNode(true).play();
    w.color = b.color;




    // sound.c4.cloneNode(true).play();


  }
}
