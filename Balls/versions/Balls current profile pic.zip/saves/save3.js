var data = {
  description: "Test for stuff",
  versions: ["v1.0.0", "v1.0.1"],
  config: {
    doFriction: false,
    doCollision: false,
    doGravity: true,
    doCombinition: false,
    doWorldBorder: false,

    doDrawPath: false,
    doVelVec: false,

    gameSpeed: 2,
    gameIntTime: 20,
    gameScale: 1,
    gameSize: [600, 600], // 0 if none
    // gameSize: [400, 600], // 0 if none

    accPlayer: 1, // Player Acceleration
  },
  phys: {
    fric: 0.0008,
    G: 4
  },
  entities: [
    {
      x: 100,
      y: 300,
      r: 40,
      color: "hsl(0, 100%, 50%)",
      m: 40,
      elast: 1,
      vel: [0, 0.6]
    },
    {
      x: 500,
      y: 300,
      r: 40,
      color: "red",
      m: 40,
      elast: 1,
      vel: [0, -0.6]
    },

    {
      x: 300,
      y: 100,
      r: 40,
      color: "hsl(0, 100%, 50%)",
      m: 40,
      elast: 1,
      vel: [-0.6, 0]
    },
    {
      x: 300,
      y: 500,
      r: 40,
      color: "red",
      m: 40,
      elast: 1,
      vel: [0.6, 0]
    },
    // {
    //   x: 50,
    //   y: 250,
    //   r: 20,
    //   color: "hsl(0, 100%, 50%)",
    //   m: 40,
    //   elast: 1,
    //   vel: [1, -1]
    // },
    // {
    //   x: 150,
    //   y: 250,
    //   r: 20,
    //   color: "hsl(0, 100%, 50%)",
    //   m: 40,
    //   elast: 1,
    //   vel: [-1, -1]
    // },
  ],
  walls: [
    // {
    //   start: [300, 420],
    //   end: [600, 200],
    //   color: "blue"
    // }
  ],
  func: function () {
    for (var i = 0; i < bls.length; i++) {
      bls[i].color = "hsl(" + counter + ", 100%, 50%)";
      // bls[i].r = Math.sin(counter * 0.1) * 5 + 5;

    }
    // bls[0].color = "hsl(" + counter + ", 100%, 50%)";
    // friction += 0.00001

  },
  onBounce: function () {
    // bls[0].vel = bls[0].vel.mul(1.1);
    // sound.woodenPop.cloneNode(true).play();
  }
}
