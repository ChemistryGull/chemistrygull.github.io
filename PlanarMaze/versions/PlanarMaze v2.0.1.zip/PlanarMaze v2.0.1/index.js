'use strickt'

const electron = require('electron');
const {app, BrowserWindow} = electron;

require("electron-reload")(__dirname)






app.on("ready", () => {
  let win = new BrowserWindow(
    {
      width: 800,
      height:800,
      webPreferences: {
          nodeIntegration: true
      }
    })
  win.maximize()
  win.loadURL(`file://${__dirname}/index.html`)
  win.openDevTools()
})
