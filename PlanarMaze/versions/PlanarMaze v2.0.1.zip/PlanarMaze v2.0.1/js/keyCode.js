var keyCode = {
  mLeft: 65, //A
  mRight: 68, //D
  mUp: 87, //W
  mDown: 83, //S

  mSpeed: 16, //Shift
  interact: 32, //Space
  f12: 123,
  f5: 116
}
