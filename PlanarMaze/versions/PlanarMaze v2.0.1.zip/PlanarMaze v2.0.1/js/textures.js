var tileTEX = null;
var tileTEX_URL= "assets/Tiles_TEX.png";
var tileTEX_loaded= false;

var tileTypes = {
  g1: {name: "Grass", type: "floor", transparent: true, x: 0,y:0},
  sw1: {name: "StoneWall", type: "wall", transparent: false, x: 1,y:0},
  w1: {name: "Water", type: "fluid", transparent: true, x: 2,y:0},
  d1: {name: "Dirt", type: "floor", transparent: true, x: 3,y:0},
  s1: {name: "Sand", type: "floor", transparent: true, x: 4,y:0},
  l1: {name: "Lava", type: "fluid", transparent: true, x: 5,y:0},

  btn1: {name: "buttonFloor", type: "obj", transparent: true, x: 0,y:1},
}
