var entityList = [
  {
    type: "button",
    texture: "btn1",
    x: 6,
    y: 4,
    action: {
      act: "tileChange",
      target: 247,
      changeTo: "g1"
    }


  }
]
