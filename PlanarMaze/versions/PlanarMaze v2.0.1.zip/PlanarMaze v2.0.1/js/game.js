var gameMetaData = {
  Creator: "ChemistryGull",
  version: "2.0.1",
  ChangeLog: [
    "Removed old ray renderer",
    "Added trigonometric game renderer with side rays",
    "Added trigonometric game renderer without side rays",
    "Added Time Counters",
    "Added colored FPS",
    "AddFile entities.js",
    "Added entity()",
    "Added rendering of entities and basic function of buttons"
  ]
}




var ctx = null;
var tileW = 32;
var tileH = 32;


// --- FrameCount
var currentSecond = 0;
var frameCount = 0;
var framesLastSecond = 0;



// --- Key Management
var keys = [];

// --- define Player
var player = new character(20, 20, 150, 150, 2, "#ff6600");
var lastTileOn;
// var speedReduction = 0.70710678;
var speedReduction = 1;
var scale = 2;

// --- entities
var entities = [];


// --- Rendering

const pi180 = (Math.PI/180);
const angles =[...new Array(360).fill(0)].map((_,i) => ({
  cos: Math.cos(i * pi180),
  sin: Math.sin(i * pi180)
}));

var sideRay = true; // --- true: use side rays to look at neighbor tiles; false: only use single ray (needs more Rays)
var raysSide = 32; // --- is used when side Ray is true
var rays = 1024; // --- is used when side Ray is false
var rayRadius = 16;

// --- FPS counter
var starterFrameCount = 0;
var fps, fpsInterval, startTime, now, then, elapsed;

// --- Game counter is for stopping movement of player diagonally sometimes to slow down; goes 0-9
var gameCounter = 0;


window.onload = function () {

  ctx = document.getElementById("game").getContext("2d");
	document.getElementById('game').width = $("#gameFrame").width();
	document.getElementById('game').height = $("#gameFrame").height();

	viewport.screen = [$("#game").width(), $("#game").height()];
	ctx.scale(scale, scale);
	viewport.screen[0] /= scale;
	viewport.screen[1] /= scale;


	// --- Event Listerers

	window.addEventListener("keydown", function (e) {
    if (e.keyCode == keyCode.f12 || e.keyCode == keyCode.f5 ) {
      return;
    }
		e.preventDefault();
		keys = (keys || []);
		keys[e.keyCode] = true;
	});
	window.addEventListener("keyup", function (e) {
		keys[e.keyCode] = false;
	})
	window.addEventListener("resize", function () {
		document.getElementById('game').width = $("#gameFrame").width();
		document.getElementById('game').height = $("#gameFrame").height();
		viewport.screen = [$("#game").width(), $("#game").height()];
		// ctx.scale(1/scale, 1/scale);
		ctx.scale(scale, scale);
		viewport.screen[0] /= scale;
		viewport.screen[1] /= scale;
	});


	player.collide();


	// --- Load Tilesets
	tileTEX = new Image();
	tileTEX.src = tileTEX_URL;
	tileTEX.onerror = function () {
		ctx = null;
		alert("Failed Loading Tileset");
	}
	tileTEX.onload = function () {
		tileTEX_loaded = true;
	}


  // --- entities

  for (var i = 0; i < entityList.length; i++) {
    entities[i] = new entity(entityList[i].x, entityList[i].y, entityList[i].type, entityList[i].texture, entityList[i].action);
  }


	// requestAnimationFrame(drawGame);
	startAnimating(60);
	// drawGame();

}


function character(w, h, x, y, speed, color) {
	this.width = w;
  this.height = w;
  this.speedX = 0;
	this.speedY = 0;
  this.speed = speed;
  this.x = x;
  this.y = y;
  this.cx = this.x + (this.width / 2);
  this.cy = this.y + (this.height / 2);
	this.tileOn = [];
	this.update = function () {
		ctx.fillStyle = color;
		ctx.fillRect((viewport.offset[0] + this.x), (viewport.offset[1] + this.y), this.width, this.height);
    this.cx = this.x + (this.width / 2);
    this.cy = this.y + (this.height / 2);
    ctx.fillStyle = "purple";
		ctx.fillRect((viewport.offset[0] + this.cx) - 2, (viewport.offset[1] + this.cy) - 2, 4, 4);
	};
	this.move = function () {
		this.x += this.speedX;
		this.y += this.speedY;

	};
	this.collide = function () {

		this.onTile = Math.floor((this.y + this.height / 2) / tileH) * mapW + Math.floor((this.x + this.width / 2) / tileW);

		this.tileOn[0] = gameMap[Math.floor(this.y / tileH) * mapW + Math.floor((this.x + this.speed) / tileW)];
		this.tileOn[1] = gameMap[Math.floor(this.y / tileH) * mapW + Math.floor((this.x + this.width - this.speed) / tileW)];

		this.tileOn[2] = gameMap[Math.floor((this.y + this.speed) / tileH) * mapW + Math.floor((this.x + this.width) / tileW)];
		this.tileOn[3] = gameMap[Math.floor((this.y + this.height - this.speed) / tileH) * mapW + Math.floor((this.x + this.width) / tileW)];

		this.tileOn[4] = gameMap[Math.floor((this.y + this.height) / tileH) * mapW + Math.floor((this.x + this.width - this.speed) / tileW)];
		this.tileOn[5] = gameMap[Math.floor((this.y + this.height) / tileH) * mapW + Math.floor((this.x + this.speed) / tileW)];

		this.tileOn[6] = gameMap[Math.floor((this.y + this.height - this.speed) / tileH) * mapW + Math.floor(this.x / tileW)];
		this.tileOn[7] = gameMap[Math.floor((this.y + this.speed) / tileH) * mapW + Math.floor(this.x / tileW)];


		if (tileTypes[this.tileOn[0]].type == "wall" || tileTypes[this.tileOn[1]].type == "wall") {
			if (keys[keyCode.mUp]) {
				this.speedY = 0;
			}
		}
		if (tileTypes[this.tileOn[2]].type == "wall" || tileTypes[this.tileOn[3]].type == "wall") {
			if (keys[keyCode.mRight]) {
				this.speedX = 0;
			}
		}
		if (tileTypes[this.tileOn[4]].type == "wall" || tileTypes[this.tileOn[5]].type == "wall") {
			if (keys[keyCode.mDown]) {
				this.speedY = 0;
			}
		}
		if (tileTypes[this.tileOn[6]].type == "wall" || tileTypes[this.tileOn[7]].type == "wall") {
			if (keys[keyCode.mLeft]) {
				this.speedX = 0;
			}
		}


    // if (tileTypes[this.tileOn[0]].type == "fluid" || tileTypes[this.tileOn[1]].type == "fluid" || tileTypes[this.tileOn[2]].type == "fluid" || tileTypes[this.tileOn[3]].type == "fluid" || tileTypes[this.tileOn[4]].type == "fluid" || tileTypes[this.tileOn[5]].type == "fluid" || tileTypes[this.tileOn[6]].type == "fluid" || tileTypes[this.tileOn[7]].type == "fluid") {
		// 	if (gameCounter % 2 == 0) {
    //     this.speedX = 0;
		// 		this.speedY = 0;
		// 	}
		// }
    if (tileTypes[gameMap[Math.round(player.x / tileW) + Math.round(player.y / tileH) * mapW]].type == "fluid") {
			if (gameCounter % 2 == 0) {
        this.speedX = 0;
				this.speedY = 0;
			}
		}


	}

}

function entity(x, y, type, texture, act) {
  this.x = x;
  this.y = y;
  this.type = type;
  this.texture = texture;
  this.action = act;
  this.tileOn = this.y * mapW + this.x;
  this.update = function () {
    ctx.drawImage(tileTEX, tileTypes[this.texture].x * (tileW + 2) + 1, tileTypes[this.texture].y * (tileH + 2) + 1, tileW, tileH, viewport.offset[0] + this.x * tileW, viewport.offset[1] + this.y * tileH, tileW, tileH);
    this.tileOn = this.y * mapW + this.x;
  }
  this.tileChange = function () {
    gameMap[this.action.target] = this.action.changeTo;
    console.log("--- TileChanged");
  }

}



function startAnimating(fps) {
    fpsInterval = 1000 / fps;
    then = Date.now();
    startTime = then;
    animate();
}


function animate() {

    // stop
		if (keys[27]) {console.warn("Stop");return;}


    // request another frame

    requestAnimationFrame(animate);

    // calc elapsed time since last loop

    now = Date.now();
    elapsed = now - then;

    // if enough time has elapsed, draw the next frame

    if (elapsed > fpsInterval) {

        // Get ready for next frame by setting then=now, but...
        // Also, adjust for fpsInterval not being multiple of 16.67
        then = now - (elapsed % fpsInterval);

        // draw stuff here


        // TESTING...Report #seconds since start and achieved fps.
        // var sinceStart = now - startTime;
        // var currentFps = Math.round(1000 / (sinceStart / ++starterFrameCount) * 100) / 100;
				// console.log("Elapsed time= " + Math.round(sinceStart / 1000 * 100) / 100 + " secs @ " + currentFps + " fps.");
				drawGame();

    }
}

function drawGame () {
	// --- check for start permition
	if (ctx == null) {
    alert("Oops, Something ist wrong, because ctx == null.")
    return;
  }
	if (!tileTEX_loaded) {
		requestAnimationFrame(drawGame);
	}

  var renderPerformanceStart = performance.now();

	// --- frameCount
  var sec = Math.floor(Date.now()/1000);
  if (sec != currentSecond) {
    currentSecond = sec;
    framesLastSecond = frameCount;
    frameCount = 1;

  } else {
    frameCount++;
  }

  // --- gameCounter
  if (gameCounter < 10) {
    gameCounter++
  } else {
    gameCounter = 0;
  }

	// --- clear Screen
	ctx.fillStyle = "#000000";
	// ctx.fillStyle = "rgba(0, 0, 0, 0.01)";
	ctx.fillRect(0, 0, viewport.screen[0], viewport.screen[1]);



	// --- Draw Tiles (Type: whole_area)
  // for (var y = viewport.startTile[1]; y < viewport.endTile[1]; y++) {
  //   for (var x = viewport.startTile[0]; x < viewport.endTile[0]; x++) {
	//
	//
	// 		// if (tileTypes[gameMap[mapW * y + x]].transparent) {
	// 		// 	var curTileInfo = tileTypes[gameMap[mapW * y + x]]
	// 		// 	ctx.drawImage(tileTEX, curTileInfo.x * (tileW + 2) + 1, curTileInfo.y * (tileH + 2) + 1, tileW, tileH, viewport.offset[0] + x * tileW, viewport.offset[1] + y * tileH, tileW, tileH);
	// 		// }
	//
	// 		var curTileInfo = tileTypes[gameMap[mapW * y + x]]
	// 		ctx.drawImage(tileTEX, curTileInfo.x * (tileW + 2) + 1, curTileInfo.y * (tileH + 2) + 1, tileW, tileH, viewport.offset[0] + x * tileW, viewport.offset[1] + y * tileH, tileW, tileH);
	//
  //   }
  // }


	// Render rays with angles


	var startTime = performance.now()

	// --- Render Rays compiled

	var drawData = [];

  if (sideRay) {
    for (var ang = 0; ang < Math.PI * 2; ang += Math.PI / raysSide) {
  		for (var c = 0; c < rayRadius; c++) {
  			var drawingX = Math.round(player.x / tileW + c * (Math.cos(ang)));
  			var drawingY = Math.round(player.y / tileH - c * (Math.sin(ang)));

  			if (drawingX > viewport.endTile[0] || drawingY > viewport.endTile[1] || drawingX < viewport.startTile[0] || drawingY < viewport.startTile[1]) {
  				break;
  			}


  			// --- Draw Main Line


  			if (!drawData.includes(drawingX + drawingY * mapW)) {
  				drawData.push(drawingX + drawingY * mapW);
  			}
  			var curTileInfo = tileTypes[gameMap[drawingX + drawingY * mapW]];


  			if (!curTileInfo.transparent) {
  				break;
  			}



  			// --- Draw Side Arms (left)

  			var drawingX = Math.round(player.x / tileW + c * (Math.cos(ang)) + Math.round(Math.cos(ang + Math.PI / 4)));
  			var drawingY = Math.round(player.y / tileH - c * (Math.sin(ang)) - Math.round(Math.sin(ang + Math.PI / 4)));

  			if (!drawData.includes(drawingX + drawingY * mapW)) {
  				drawData.push(drawingX + drawingY * mapW);
  			}



  			// --- Draw Side Arms (right)

  			var drawingX = Math.round(player.x / tileW + c * (Math.cos(ang)) - Math.round(Math.cos(ang + Math.PI / 1.25)));
  			var drawingY = Math.round(player.y / tileH - c * (Math.sin(ang)) + Math.round(Math.sin(ang + Math.PI / 1.25)));

  			if (!drawData.includes(drawingX + drawingY * mapW)) {
  				drawData.push(drawingX + drawingY * mapW);
  			}


  		}
  	}
  } else if (!sideRay) {
    for (var ang = 0; ang < Math.PI * 2; ang += Math.PI / rays) {
  		for (var c = 0; c < rayRadius; c++) {
  			var drawingX = Math.round(player.x / tileW + c * (Math.cos(ang)));
  			var drawingY = Math.round(player.y / tileH - c * (Math.sin(ang)));

  			if (drawingX > viewport.endTile[0] || drawingY > viewport.endTile[1] || drawingX < viewport.startTile[0] || drawingY < viewport.startTile[1]) {
  				break;
  			}

  			// --- Draw Main Line


  			if (!drawData.includes(drawingX + drawingY * mapW)) {
  				drawData.push(drawingX + drawingY * mapW);
  			}
  			var curTileInfo = tileTypes[gameMap[drawingX + drawingY * mapW]];


  			if (!curTileInfo.transparent) {
  				break;
  			}

  		}
  	}
  }


	for (var i = 0; i < drawData.length; i++) {

		var curTileInfo = tileTypes[gameMap[drawData[i]]];

		var drawingX = drawData[i] % mapW;
		var drawingY = (drawData[i] - drawingX) / mapW;

		if (curTileInfo) {
			ctx.drawImage(tileTEX, curTileInfo.x * (tileW + 2) + 1, curTileInfo.y * (tileH + 2) + 1, tileW, tileH, viewport.offset[0] + drawingX * tileW, viewport.offset[1] + drawingY * tileH, tileW, tileH);
		}

	}


  for (var i = 0; i < entities.length; i++) {
    if (drawData.includes(entities[i].tileOn)) {
      entities[i].update();
      if (entities[i].action) {
        switch (entities[i].action.act) {
          case "tileChange":
            if (keys[keyCode.interact]) {
              entities[i].tileChange();
            }
            break;
          default:

        }
      }
    }
  }

	var endTime = performance.now()



	// --- Draw one single Ray (angles)
	ctx.fillStyle = "#ff0000";




	// --- Player
	player.speedX = 0;
	player.speedY = 0;
	if (keys[keyCode.mLeft]) {player.speedX -= player.speed;}
	if (keys[keyCode.mRight]) {player.speedX += player.speed;}
	if (keys[keyCode.mUp]) {player.speedY -= player.speed;}
	if (keys[keyCode.mDown]) {player.speedY += player.speed;}
	if (keys[16]) {
			player.speedX *= 2;
			player.speedY *= 2;
	}
	if ((player.speedX && player.speedY) != 0) {
			player.speedX *= speedReduction;
			player.speedY *= speedReduction;

      // --- GameCounter to only allow 7 in 10 movement frames
      if (gameCounter == 0 || gameCounter == 3 || gameCounter == 6) {
        player.speedX = 0;
  			player.speedY = 0;
      }
	}
	player.collide();
	player.update();
	player.move();

	viewport.update(player.x + player.width / 2, player.y + player.height / 2);



	// --- Text Drawer

  var grd = ctx.createRadialGradient($("#gameFrame").width() / (2 * scale), $("#gameFrame").height() / (2 * scale), $("#gameFrame").height() / (6 * scale), $("#gameFrame").width() / (2 * scale), $("#gameFrame").height() / (2 * scale), $("#gameFrame").height() / (1.7 * scale));
  grd.addColorStop(0, "transparent");
  grd.addColorStop(1, "black");

  // Fill with gradient
  ctx.fillStyle = grd;
  ctx.fillRect(0, 0, $("#gameFrame").width(), $("#gameFrame").height());

	ctx.shadowColor = "black";
	ctx.shadowBlur = 6;
	if (framesLastSecond >= 60) {
		ctx.fillStyle = "limegreen";
	} else if (framesLastSecond > 40) {
		ctx.fillStyle = "lime";
	} else if (framesLastSecond > 20) {
		ctx.fillStyle = "yellow";
	} else {
		ctx.fillStyle = "#AB0000";
	}

	ctx.fillText("FPS: " + framesLastSecond, 10, 20);


	ctx.fillStyle = "#ff0000";

	ctx.fillText("Render Execution Time: " + Math.round(endTime - startTime) + " ms", 60, 20);
	ctx.fillText("Current Tile On: " + tileTypes[gameMap[player.onTile]].name + " " + player.onTile, 10, 40);
	ctx.fillText("Player Pos: " + player.x + " | " + player.y, 10, 60);
	ctx.fillText("Player Tile: " + Math.round(player.x / tileW) + " | " + Math.round(player.y / tileH), 10, 80);


  var renderPerformanceEnd = performance.now();
  ctx.fillText("Game Frame Time: " + Math.round(renderPerformanceEnd - renderPerformanceStart) + " ms", 200, 20);


	ctx.shadowBlur = 0;

	// --- Debug Exit

	if (keys[27]) {console.warn("Stop");return;}


  // requestAnimationFrame(drawGame);

}
