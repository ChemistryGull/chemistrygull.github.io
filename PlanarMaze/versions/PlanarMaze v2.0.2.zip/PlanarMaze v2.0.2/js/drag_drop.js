function buildInvSpace(invList, targetInv) {

  var timeBuildInv_Start = performance.now()

  var targetId = targetInv.split("-")[1]
  // var targetInvID = targetInv;
  // var targetInv = targetInv.split(",")[0]

  var elemInventory = $("<div>").attr({class: "inventory", id: targetInv})
  var elemInventoryCon = $("<div>").attr({class: "inventoryCon"})
  var elemInventoryConCon = $("<div>").attr({class: "inventoryConCon"})


  elemInventoryCon.append(elemInventory)

  elemInventoryConCon.append($("<h1>").text(targetInv))
  elemInventoryConCon.append(elemInventoryCon)

  $("#sideMenu").append(elemInventoryConCon)

  for (var i = 0; i < invList.length; i++) {
    var itemSpace = $("<div>").attr({class: "itemCon", id: "iC|" + i + "|" + targetInv});

    itemSpace.get(0).addEventListener("drop", function (ev) {
      ev.preventDefault();

      // --- Frontend Change

      var elementMoved = document.getElementById(ev.dataTransfer.getData("text")); // This is the element the cursor holds (it is dragged).
      var placeFrom = elementMoved.parentNode; // This is the Container where the item you hold is from (it is now empty, the replacedItem has to jump there).
      var replacedItem = ev.currentTarget.firstElementChild; // This is the item on which you drop the item you hold.
      var targetPlace = ev.currentTarget; // The container you currently hover over. The items will be replaced on drop.

      targetPlace.replaceChild(elementMoved, replacedItem);
      placeFrom.appendChild(replacedItem);

      // --- Backend Change (moved to saveInvChange)

      // var itemHold = elementMoved.id.split("|")[1];
      // var itemSwitch = replacedItem.id.split("|")[1];
      //
      //
      //
      // var itemHoldToPlace = targetPlace.id.split("|")[1];
      // var itemSwitchToPlace = placeFrom.id.split("|")[1];
      //
      //
      //
      // invList[itemHoldToPlace] = itemHold;
      // invList[itemSwitchToPlace] = itemSwitch;


      saveInvChange();


    })
    itemSpace.get(0).addEventListener("dragover", function (ev) {
      ev.preventDefault();

    })

    // TODO: error because empty array
    var itemI = $("<div>").attr({title: itemTypes[invList[i]].name, draggable: true, id: "item|" + invList[i] + "|" + i + "|" + targetInv});



    itemI.get(0).addEventListener("dragstart", function (ev) {

      ev.dataTransfer.setData("text", ev.target.id);

      ev.dataTransfer.effectAllowed = "move";
    })

    // if (invList[i] == "") {
    //   itemI.attr("draggable", false);
    // }

    // console.log(itemI.get(0));

    var finItem = itemSpace.append(itemI);


    $("#" + targetInv).append(finItem);
    // ilol.appendTo($(".inventory"))
    // console.log(finItem);
  }
  drawInvItems(invList, targetInv);

  var timeBuildInv_End = performance.now()
  console.log("--- Create " + targetInv + " Time: " + Math.round((timeBuildInv_End - timeBuildInv_Start) * 10) / 10);
}

function drawInvItems(invList, targetInv) {
  vpChange()
  for (var i = 0; i < invList.length; i++) {
    if (invList[i] == "") {
      continue;
    }

    $("#" + targetInv).children().eq(i).children().css("background", "url(assets/Item_TEX.png) " + itemTypes[invList[i]].x * -$(".itemCon").children().eq(i).width() + "px " + itemTypes[invList[i]].y * -$(".itemCon").children().eq(i).width() + "px ");

    var itemSizeBG = $("#" + targetInv).children().eq(i).children().width() * itemTEX_size / 34; // because width is not 34, it is dynamic, therefore we have to take the real width to account (not height, because it is not always finished), same above.

    $("#" + targetInv).children().eq(i).children().css("background-size", itemSizeBG + "px " + itemSizeBG + "px ");

  }

  vpChange()

}

function saveInvChange() {


  // --- ACHTUNG: Bissi pfusch, funktioniert nicht dynamisch, weil es nicht möglich ist invList von beiden (target item & swap item) witer zu geben (nur wo item gedroppt wird)
  // --- Wird erst probleme machen, wenn irgendwas ein inventar hat, des ned a chest is

  for (var i = 0; i < $(".inventory").length; i++) {
    var invListTemp = [];
    for (var e = 0; e < $(".inventory").eq(i).children().children().length; e++) {
      invListTemp.push($(".inventory").eq(i).children().children().eq(e).attr("id").split("|")[1]);
    }

    if ($(".inventory").eq(i).attr("id") == "invPlayer") {
      player.inv = invListTemp;
    }
    if ($(".inventory").eq(i).attr("id").split("-")[0] == "invChest") {
      entities[entities.findIndex(e => { return e.id == $(".inventory").eq(i).attr("id").split("-")[1]})].custom.inv = invListTemp;
    }
  }


}


$(window).on("resize", function () {

  // buildInvSpace(30, "invChest")


})
